﻿=== Gun Advanced Cursor Set ===

By: The Sword of the Heart (http://www.rw-designer.com/user/1674)

Download: http://www.rw-designer.com/cursor-set/advanced

Author's decription:

You know Gun Animated...you've hoped...you've dreamed for more. A drawing simply wasn't enough.

Now I bring you Gun Cursor Advanced, complete with a real gun graphic (thanks, CursorMania), animation, and semitransparent crosshairs.
Enjoy. ;)

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.